
const versiculos = [
  "O amor é paciente, o amor é bondoso. (1 Coríntios 13:4)",
  "Melhor é serem dois do que um. (Eclesiastes 4:9)",
  "Deus é amor. (1 João 4:8)"
];

let passoAtual = 1;

function proximoPasso() {
  document.getElementById("passo" + passoAtual).classList.remove("active");
  passoAtual++;
  document.getElementById("passo" + passoAtual).classList.add("active");
}

function mostrarTexto(i) {
  const texto = versiculos[i];
  const elemento = document.getElementById("textoVersiculo");
  let idx = 0;
  elemento.innerHTML = "";
  function escrever() {
    if (idx < texto.length) {
      elemento.innerHTML += texto.charAt(idx);
      idx++;
      setTimeout(escrever, 30);
    }
  }
  escrever();
}

function verificarQuiz() {
  const q1 = document.querySelector('input[name="q1"]:checked');
  const q2 = document.querySelector('input[name="q2"]:checked');
  if (!q1 || !q2) {
    document.getElementById("erroQuiz").innerText = "Responda todas as perguntas!";
    return;
  }
  document.getElementById("campoQuiz").value = `Q1: ${q1.value}, Q2: ${q2.value}`;
  proximoPasso();
}

function responder(resposta) {
  document.getElementById("campoResposta").value = resposta;
  proximoPasso();
}

function escolherEncontro(tipo) {
  document.getElementById("campoEncontro").value = tipo;
  document.getElementById("formulario").submit();
  document.getElementById("passo5").classList.remove("active");
  document.getElementById("passo6").classList.add("active");
  const musica = document.getElementById("musica");
  if (document.getElementById("campoResposta").value === "Sim") {
    document.getElementById("respostaFinal").innerText = "Você aceitou! 💖";
    if (tipo.includes("Piquenique")) {
      document.getElementById("mensagemFinal").innerText = "Eu já até imaginei a gente no parque... risadas, flores e você sorrindo do meu lado. Mal posso esperar 😍";
    } else {
      document.getElementById("mensagemFinal").innerText = "Vai ser um momento muito especial. Mal posso esperar!";
    }
    musica.play();
    estourarConfete();
  } else {
    document.getElementById("respostaFinal").innerText = "Tudo bem, Amanda 😢";
    document.getElementById("mensagemFinal").innerText = "Mesmo assim, obrigado por olhar com carinho ❤️";
  }
}

function criarCoracoes() {
  const container = document.getElementById("coracoes");
  for (let i = 0; i < 30; i++) {
    const c = document.createElement("div");
    c.classList.add("coracao");
    c.innerText = "💖";
    c.style.left = Math.random() * 100 + "vw";
    c.style.animationDuration = (3 + Math.random() * 5) + "s";
    container.appendChild(c);
  }
}

function estourarConfete() {
  for (let i = 0; i < 100; i++) {
    const c = document.createElement("div");
    c.classList.add("coracao");
    c.innerText = "🎉";
    c.style.left = Math.random() * 100 + "vw";
    c.style.fontSize = "24px";
    c.style.animationDuration = (2 + Math.random() * 4) + "s";
    document.getElementById("coracoes").appendChild(c);
  }
}

criarCoracoes();
